# AdvanceToll
Project : Advance Toll Booth automation  
Me and my team work on this project and the prototype was selected by NASSCOM and CYBAGE companies.


Advance Toll Booth Automation is actually based on paying the toll without stopping at Toll Booth. It actually saves the time,Fuel money. prevent long queue and also prevent travellers through various emotional frustrations.

The Project includes a camera which will capture the image of registered plate number. Through Begalbone we will sent the image to our main server where the process of matching the numbers will take place. Simultaneously through Our android application , if a user has paid for the toll his registration number will be matched and will be permitted to pass through.

Image processing files are uploaded above.
For Android application you can see the prototype : https://drive.google.com/open?id=0B529HQ0k77iANUNiZ29lSXMyb1E :) 
